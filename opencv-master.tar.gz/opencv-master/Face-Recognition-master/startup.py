import sys
import os
import time
import paho.mqtt.client as mqtt

MQTT_HOST = '192.168.43.71'
USER = 'HA'
Password = '123456'


def on_message(client, userdata, message):
    print("message topic=",message.topic)
    print(message.payload)
    val = ''
    val = message.payload
    if val == "Detect":
    	os.system('python detector.py')
        #exit(0)

client = mqtt.Client()
client.username_pw_set(USER,Password)
client.connect(MQTT_HOST, 1808)
client.on_message = on_message
client.loop_start()
if __name__ == '__main__':
	while True:
		print("Subrice den topic sau:\n")
		client.subscribe("detect")
		time.sleep(5)
# client.loop_stop()
# client.disconnect()
