#!/bin/sh
python detector.py
