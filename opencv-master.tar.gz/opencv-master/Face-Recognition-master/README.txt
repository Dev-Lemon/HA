### Require install
* Python 2.x
* OpenCV 2.x
* Numpy

## Running the tests

* run the dataSetGenerator.py and enter a your name to create face samples with your face
* run trainer.py to train faces
* run detector.py to dectect faces

## Authors

* **[Anirban Kar](http://thecodacus.com/author/admin/)**

## Editor

* **[Hien Phan](http://github.com/hienpvptit) **
